

 <?php

  $host='localhost';
  $db='collection';
  $dbuser='root';
  $dbpw=''; 
   

  try
  {
    $bdd = new PDO('mysql:host='.$host.';dbname='.$db, ''.$dbuser.'', ''.$dbpw.'');
    $bdd->exec("set names utf8");
  }
  catch (Exception $e)
  {
    die('Erreur : ' . $e->getMessage());
  } 

  date_default_timezone_set('Africa/Kigali');
  setlocale (LC_TIME, 'fr_FR','fra');

   

?>




 <?php 

    require('save.php');
    
  
    
  ?>
  



<html lang="en">
<head>
    <title>Form page</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        .form-group{
            display: inline-block;
        }
    </style>
</head>
<body>

    <div class="container">
         <div class="form-horizontal" role="form" action="" method="POST"   name="fileinfo" id="upload">


        <div class="">

            <div>
                <button class="btn btn-primary btn-sm" onclick="removeItem()">-</button>
                <span id="number-span">1</span>
                <button class="btn btn-primary btn-sm" onclick="duplicate();">+</button>
            </div>

          
            <div class="data" id="data-page">
                <div class="form-group" id="form-group">
                    <label for="name">Choose level</label>
                    <select name="name" id="name" class="form-control">
                        <option value="Nursery">Nursery</option>
                        <option value="Primary 1">Primary 1</option>
                        <option value="Primary 2">Primary 2</option>
                        <option value="Primary 3">Primary 3</option>
                        <option value="Primary 4">Primary 4</option>
                        <option value="Primary 5">Primary 5</option>
                        <option value="Primary 6">Primary 6</option>
                        
                    </select>
                </div>
            </div>
                 
        </div>
        <input id="sbmt_about" name="sbmt_about" value="Next (1/3)" class="form-controls input-md" type="submit" /> 
    </form>





          <script>
                function duplicate() {
                    var div = document.getElementById("form-group");
                    document.getElementById("data-page").appendChild(div.cloneNode(true));
                    var data = document.getElementById("number-span");
                    data.textContent = parseInt(data.textContent)+1;
                }
                function removeItem() {
                    var content = document.getElementById("data-page");
                    if( content.children.length > 1) {
                        content.lastChild.remove();
                        var data = document.getElementById("number-span");
                        data.textContent = parseInt(data.textContent) - 1;
                    }
                }
            </script>
    </div>
</body>
</html>