<!DOCTYPE html>
<html>
<head>
	<title>page 2</title>
</head>
<body>
	
		<h4>Child 1</h4>
		<div class="child" style="border:1px solid #ddd;width: 30%;padding: 10px 30px;">
		<p>What's your goal for this child?</p>
		<select>
			<option>Select a goal</option>
			<option>Help with assignments and school work</option>
			<option>Improve phonics, reading and writing</option>
			<option>Entrance exam preparation</option>
		</select>

		<p>What subjects?</p>
		<select>
			<option>Select a subject</option>
			<option>Basic Mathematics</option>
			<option>Verbal Reasoning</option>
			<option>Entrance exam preparation</option>
			
		</select>
	</div>

</body>
</html>