<?php 
	if(isset($_POST['sbmt_about']) && $_POST['sbmt_about'] == 'Next (1/3)')
	{ 


	$child = $_POST['name'];
   
		
	for ($i=0; $i < count($child); $i++) { 

   //$inserer = $bdd -> prepare ("UPDATE INTO bookings SET meals = ". $_POST['level_child'][$i]." ");
   $inserer = $bdd -> prepare ('INSERT INTO booking SET class = ?');
   $inserer -> execute(array($child[$i])) or die(print_r($inserer->errorInfo()));
   
  
				
			}
			header('Location: page_2.php');
			
		}	
		
		
		
		
		
	
		
?>